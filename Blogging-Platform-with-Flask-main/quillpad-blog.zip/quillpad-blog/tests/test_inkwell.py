"""Week 7 - automated tests.  Run:  python -m unittest discover -v"""
import os
import re
import tempfile
import unittest

from quillpad import create_app


class QuillpadTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".sqlite")
        os.close(fd)
        self.app = create_app({"TESTING": True, "DATABASE": self.path,
                               "CSRF_ENABLED": False, "SECRET_KEY": "test", "POSTS_PER_PAGE": 3})
        self.client = self.app.test_client()

    def tearDown(self):
        os.unlink(self.path)

    # helpers
    def register(self, c=None, name="alice", pw="password123"):
        c = c or self.client
        return c.post("/auth/register", data={"username": name, "email": f"{name}@x.com",
                                              "password": pw, "confirm": pw}, follow_redirects=True)

    def login(self, c=None, name="alice", pw="password123"):
        c = c or self.client
        return c.post("/auth/login", data={"username": name, "password": pw}, follow_redirects=True)

    def signup_and_login(self, c=None, name="alice"):
        self.register(c, name)
        return self.login(c, name)

    def new_post(self, c=None, title="Hello World", body="This is a long enough body.", tags=""):
        c = c or self.client
        return c.post("/create", data={"title": title, "body": body, "tags": tags}, follow_redirects=True)


class AuthTests(QuillpadTestCase):
    def test_register_login_logout(self):
        self.assertIn(b"Account created", self.register().data)
        self.assertIn(b"Welcome back, alice", self.login().data)
        self.assertIn(b"logged out", self.client.post("/auth/logout", follow_redirects=True).data)

    def test_validation_and_duplicates(self):
        self.assertIn(b"at least 8", self.register(pw="short").data)
        self.register()
        self.assertIn(b"already registered", self.register().data)

    def test_wrong_password(self):
        self.register()
        self.assertIn(b"Incorrect", self.login(pw="wrongwrong").data)

    def test_password_is_hashed(self):
        self.register()
        import sqlite3
        row = sqlite3.connect(self.path).execute("SELECT password_hash FROM users").fetchone()
        self.assertNotEqual(row[0], "password123")

    def test_login_required_redirect(self):
        r = self.client.get("/create")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/auth/login", r.headers["Location"])

    def test_open_redirect_blocked(self):
        self.register()
        r = self.client.post("/auth/login?next=//evil.com", data={"username": "alice", "password": "password123"})
        self.assertNotIn("evil.com", r.headers["Location"])


class PostTests(QuillpadTestCase):
    def test_create_view_edit_delete(self):
        self.signup_and_login()
        r = self.new_post(tags="Flask, Python")
        self.assertIn(b"Post published", r.data)
        self.assertIn(b"#flask", r.data)
        self.assertIn(b"Hello World", self.client.get("/").data)
        r = self.client.post("/post/1/edit", data={"title": "Changed", "body": "Updated body text here", "tags": "x"},
                             follow_redirects=True)
        self.assertIn(b"Changed", r.data)
        r = self.client.post("/post/1/delete", follow_redirects=True)
        self.assertIn(b"Post deleted", r.data)
        self.assertEqual(self.client.get("/post/1").status_code, 404)

    def test_validation(self):
        self.signup_and_login()
        self.assertIn(b"at least 10", self.new_post(body="short").data)

    def test_only_author_can_edit_or_delete(self):
        self.signup_and_login()
        self.new_post()
        bob = self.app.test_client()
        self.signup_and_login(bob, "bob")
        self.assertEqual(bob.get("/post/1/edit").status_code, 403)
        self.assertEqual(bob.post("/post/1/delete").status_code, 403)

    def test_html_is_escaped(self):
        self.signup_and_login()
        self.new_post(title="<script>alert(1)</script>", body="<b>bold</b> body text long")
        page = self.client.get("/post/1").data
        self.assertNotIn(b"<script>alert(1)</script>", page)
        self.assertIn(b"&lt;script&gt;", page)

    def test_404_page(self):
        self.assertEqual(self.client.get("/nope").status_code, 404)


class CommentTests(QuillpadTestCase):
    def test_comment_flow_and_permissions(self):
        self.signup_and_login()
        self.new_post()
        bob = self.app.test_client()
        self.signup_and_login(bob, "bob")
        r = bob.post("/post/1/comment", data={"body": "Nice post!"}, follow_redirects=True)
        self.assertIn(b"Nice post!", r.data)
        # a third user may not delete it
        eve = self.app.test_client()
        self.signup_and_login(eve, "eve")
        self.assertEqual(eve.post("/comment/1/delete").status_code, 403)
        # post author may moderate
        self.assertIn(b"Comment deleted", self.client.post("/comment/1/delete", follow_redirects=True).data)

    def test_anonymous_cannot_comment(self):
        self.signup_and_login()
        self.new_post()
        anon = self.app.test_client()
        self.assertEqual(anon.post("/post/1/comment", data={"body": "hi"}).status_code, 302)

    def test_empty_comment_rejected(self):
        self.signup_and_login()
        self.new_post()
        self.assertIn(b"between 1 and 1000", self.client.post("/post/1/comment", data={"body": "  "}, follow_redirects=True).data)

    def test_comments_deleted_with_post(self):
        self.signup_and_login()
        self.new_post()
        self.client.post("/post/1/comment", data={"body": "c"})
        self.client.post("/post/1/delete")
        import sqlite3
        self.assertEqual(sqlite3.connect(self.path).execute("SELECT COUNT(*) FROM comments").fetchone()[0], 0)


class SearchFilterTests(QuillpadTestCase):
    def setUp(self):
        super().setUp()
        self.signup_and_login()
        self.new_post(title="Flask tips", body="All about flask routing and more", tags="flask,python")
        self.new_post(title="Cooking pasta", body="Boil water, add salt, enjoy", tags="food")
        self.new_post(title="100% effort", body="Percent sign literal search test", tags="python")

    def test_search(self):
        page = self.client.get("/?q=routing").data
        self.assertIn(b"Flask tips", page)
        self.assertNotIn(b"Cooking pasta", page)

    def test_search_wildcards_are_literal(self):
        page = self.client.get("/?q=%25").data
        self.assertIn(b"100% effort", page)
        self.assertNotIn(b"Cooking pasta", page)

    def test_tag_filter(self):
        page = self.client.get("/?tag=python").data
        self.assertIn(b"Flask tips", page)
        self.assertIn(b"100% effort", page)
        self.assertNotIn(b"Cooking pasta", page)

    def test_sort_oldest_first(self):
        page = self.client.get("/?sort=oldest").data.decode()
        self.assertLess(page.index("Flask tips"), page.index("Cooking pasta"))

    def test_pagination(self):
        self.new_post(title="Fourth post", body="Another body long enough")
        p1 = self.client.get("/").data
        self.assertIn(b"Page 1 of 2", p1)
        self.assertNotIn(b"Flask tips", p1)  # oldest lands on page 2
        self.assertIn(b"Flask tips", self.client.get("/?page=2").data)
        self.assertEqual(self.client.get("/?page=999").status_code, 200)

    def test_profile_page(self):
        self.assertIn(b"Flask tips", self.client.get("/user/alice").data)
        self.assertEqual(self.client.get("/user/ghost").status_code, 404)


class CsrfTests(unittest.TestCase):
    def test_csrf_enforced(self):
        fd, path = tempfile.mkstemp(suffix=".sqlite")
        os.close(fd)
        app = create_app({"TESTING": True, "DATABASE": path, "SECRET_KEY": "t"})
        c = app.test_client()
        self.assertEqual(c.post("/auth/login", data={"username": "a", "password": "b"}).status_code, 400)
        html = c.get("/auth/register").data.decode()
        token = re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)
        r = c.post("/auth/register", data={"csrf_token": token, "username": "carol", "email": "c@x.com",
                                           "password": "password123", "confirm": "password123"})
        self.assertEqual(r.status_code, 302)
        os.unlink(path)


if __name__ == "__main__":
    unittest.main()
