# Quillpad - a blogging platform built with Flask

A complete 8-week internship project: user accounts, blog posts (CRUD), comments,
tags, search, sorting, pagination, tests, and deployment files.

**Stack:** Python 3.9+ · Flask · SQLite (standard library) · Jinja2 · gunicorn

## Quick start

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

flask --app wsgi seed-demo        # optional: demo user + posts (demo / demo-pass-123)
flask --app wsgi run --debug      # http://127.0.0.1:5000
```

The database (`instance/quillpad.sqlite`) is created automatically on first run.

## Project structure

```
quillpad-blog/
├── quillpad/
│   ├── __init__.py      # app factory, CSRF, filters, error pages      (Week 1)
│   ├── db.py            # SQLite helpers + CLI commands                (Week 1)
│   ├── schema.sql       # users, posts, tags, post_tags, comments
│   ├── auth.py          # register / login / logout                    (Week 2)
│   ├── blog.py          # post CRUD, list, search, tags, comments      (Weeks 3-6)
│   ├── templates/       # Jinja2 templates                             (Week 4)
│   └── static/css/      # stylesheet
├── tests/test_quillpad.py                                               (Week 7)
├── wsgi.py  Procfile  Dockerfile  requirements.txt  .env.example       (Week 7)
```

## Week-by-week map

| Week | Topic | Where |
|------|-------|-------|
| Prep | Git & GitHub | see "Git & GitHub" below |
| 1 | Flask setup & structure | `quillpad/__init__.py`, `db.py`, `schema.sql` |
| 2 | User authentication | `quillpad/auth.py` (hashed passwords, sessions, login_required) |
| 3 | Blog post CRUD | `blog.py`: `/create`, `/post/<id>`, `/post/<id>/edit`, `/post/<id>/delete` |
| 4 | Frontend & navigation | `templates/`, `static/css/style.css`, pagination, profile pages |
| 5 | Commenting system | `blog.py`: add/delete comments (author or post owner can delete) |
| 6 | Search & filtering | `/?q=...&tag=...&sort=newest|oldest|popular&page=N` |
| 7 | Deployment prep & testing | `tests/`, `wsgi.py`, `Procfile`, `Dockerfile`, `.env.example` |
| 8 | Completion video | screen-record the demo flow below |

## Run the tests

```bash
python -m unittest discover -v
```

## Security built in

Hashed passwords (Werkzeug) · CSRF tokens on every POST · output auto-escaping (XSS) ·
parameterised SQL (no SQL injection) · author-only edit/delete (403) · open-redirect
protection on login · secure cookie flags · basic security headers.

## Deploying

Set environment variables (see `.env.example`):

* `SECRET_KEY` - long random string (`python -c "import secrets; print(secrets.token_hex(32))"`)
* `DATABASE_PATH` - where the SQLite file lives
* `COOKIE_SECURE=1` - when served over HTTPS

**Render / Railway / Heroku-style hosts:** push to GitHub, create a Web Service, build command
`pip install -r requirements.txt`, start command `gunicorn wsgi:app`.
Note: SQLite on free tiers can be wiped on redeploy - attach a persistent disk and point
`DATABASE_PATH` to it, or move to PostgreSQL later.

**PythonAnywhere:** upload the project, create a virtualenv, and point the WSGI file at
`from wsgi import app as application`.

**Docker:** `docker build -t quillpad . && docker run -p 8000:8000 -v quillpad-data:/data -e SECRET_KEY=... quillpad`

## Git & GitHub (preparation week)

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git init && git add . && git commit -m "Quillpad: initial commit"
git branch -M main
git remote add origin https://github.com/<you>/quillpad-blog.git
git push -u origin main
```
Tip: commit once per week's feature (e.g. `Week 2: user authentication`).

## Suggested demo script for the Week 8 video

1. Sign up and log in  2. Write a post with tags  3. Edit it  4. Comment from a second account
5. Search and filter by tag  6. Show sorting and pagination  7. Run the tests  8. Show the live deployment
