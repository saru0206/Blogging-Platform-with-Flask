"""Production entry point:  gunicorn wsgi:app"""
from quillpad import create_app

app = create_app()
