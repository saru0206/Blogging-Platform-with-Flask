"""Quillpad – a small blogging platform built with Flask."""
import os
import re
import secrets
from datetime import datetime

from flask import Flask, abort, render_template, request, session, url_for
from markupsafe import Markup, escape

from . import db


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-change-me"),
        DATABASE=os.environ.get("DATABASE_PATH", os.path.join(app.instance_path, "quillpad.sqlite")),
        CSRF_ENABLED=True,
        POSTS_PER_PAGE=6,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",
        MAX_CONTENT_LENGTH=1024 * 1024,
    )
    if test_config:
        app.config.update(test_config)

    if app.config["SECRET_KEY"] == "dev-change-me" and not (app.debug or app.testing):
        app.logger.warning("SECRET_KEY is the insecure default - set it in the environment!")

    os.makedirs(os.path.dirname(os.path.abspath(app.config["DATABASE"])), exist_ok=True)
    db.init_app(app)
    with app.app_context():
        db.init_db()

    from . import auth, blog

    app.register_blueprint(auth.bp)
    app.register_blueprint(blog.bp)

    # ---- CSRF protection -------------------------------------------------
    def _token():
        if "_csrf_token" not in session:
            session["_csrf_token"] = secrets.token_hex(16)
        return session["_csrf_token"]

    @app.before_request
    def csrf_protect():
        if not app.config["CSRF_ENABLED"]:
            return
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.form.get("csrf_token", "")
            expected = session.get("_csrf_token", "")
            if not expected or not secrets.compare_digest(sent, expected):
                abort(400, "Invalid or missing CSRF token.")

    @app.context_processor
    def template_helpers():
        def csrf_input():
            return Markup('<input type="hidden" name="csrf_token" value="%s">' % _token())

        def page_url(n):
            args = request.args.to_dict()
            args["page"] = n
            return url_for(request.endpoint, **(request.view_args or {}), **args)

        return {"csrf_input": csrf_input, "page_url": page_url}

    # ---- Template filters ------------------------------------------------
    @app.template_filter("paragraphs")
    def paragraphs(text):
        parts = re.split(r"\n\s*\n", (text or "").strip())
        html = "".join(
            "<p>%s</p>" % str(escape(p.strip())).replace("\n", "<br>") for p in parts if p.strip()
        )
        return Markup(html)

    @app.template_filter("excerpt")
    def excerpt(text, n=180):
        text = " ".join((text or "").split())
        return text if len(text) <= n else text[:n].rsplit(" ", 1)[0] + "…"

    @app.template_filter("fmtdate")
    def fmtdate(value):
        try:
            return datetime.strptime(value, "%Y-%m-%d %H:%M:%S").strftime("%b %d, %Y")
        except (TypeError, ValueError):
            return value

    # ---- Security headers & error pages ---------------------------------
    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        return resp

    for code, title in {400: "Bad request", 403: "Forbidden", 404: "Page not found", 500: "Server error"}.items():
        def handler(e, code=code, title=title):
            return render_template("error.html", code=code, title=title), code
        app.register_error_handler(code, handler)

    return app
