"""SQLite helpers (standard library only)."""
import sqlite3
from importlib import resources

import click
from flask import current_app, g
from werkzeug.security import generate_password_hash


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    schema = resources.files("quillpad").joinpath("schema.sql").read_text(encoding="utf-8")
    db.executescript(schema)
    db.commit()


@click.command("init-db")
def init_db_command():
    """Create tables (safe to run repeatedly)."""
    init_db()
    click.echo("Database initialised.")


@click.command("seed-demo")
def seed_demo_command():
    """Add a demo user and a few posts: login demo / demo-pass-123."""
    db = get_db()
    if db.execute("SELECT 1 FROM users WHERE username = 'demo'").fetchone():
        click.echo("Demo data already present.")
        return
    cur = db.execute(
        "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
        ("demo", "demo@example.com", generate_password_hash("demo-pass-123")),
    )
    uid = cur.lastrowid
    samples = [
        ("Welcome to Quillpad", "Quillpad is a small, friendly blogging platform built with Flask.\n\nWrite posts, tag them, and talk with readers in the comments.", ["welcome", "quillpad"]),
        ("Why Flask is great for learning", "Flask gives you routing, templates and sessions without hiding how the web works.\n\nThat makes it perfect for a first full-stack project.", ["flask", "python"]),
        ("Deploying your first app", "Before deploying: set a strong SECRET_KEY, turn off debug, and run behind gunicorn.", ["deployment", "python"]),
    ]
    for title, body, tags in samples:
        pid = db.execute(
            "INSERT INTO posts (author_id, title, body) VALUES (?, ?, ?)", (uid, title, body)
        ).lastrowid
        for t in tags:
            db.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (t,))
            tid = db.execute("SELECT id FROM tags WHERE name = ?", (t,)).fetchone()["id"]
            db.execute("INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)", (pid, tid))
    db.commit()
    click.echo("Seeded. Login: demo / demo-pass-123")


def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
    app.cli.add_command(seed_demo_command)
