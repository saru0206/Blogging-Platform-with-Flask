"""Weeks 3-6 - post CRUD, frontend views, comments, search & filtering."""
import math
import re

from flask import (Blueprint, abort, current_app, flash, g, redirect,
                   render_template, request, url_for)

from .auth import login_required
from .db import get_db

bp = Blueprint("blog", __name__)

TAG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,29}$")
SORTS = {
    "newest": "p.created_at DESC, p.id DESC",
    "oldest": "p.created_at ASC, p.id ASC",
    "popular": "comment_count DESC, p.created_at DESC, p.id DESC",
}


# ---------------------------------------------------------------- helpers
def parse_tags(raw):
    tags = []
    for t in (raw or "").split(","):
        t = re.sub(r"\s+", "-", t.strip().lower())
        if TAG_RE.match(t) and t not in tags:
            tags.append(t)
    return tags[:5]


def validate_post(title, body):
    errors = []
    if not (1 <= len(title) <= 120):
        errors.append("Title is required (max 120 characters).")
    if len(body) < 10:
        errors.append("Post body must be at least 10 characters.")
    if len(body) > 20000:
        errors.append("Post body is too long (max 20,000 characters).")
    return errors


def save_tags(db, post_id, tags):
    db.execute("DELETE FROM post_tags WHERE post_id = ?", (post_id,))
    for name in tags:
        db.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (name,))
        tid = db.execute("SELECT id FROM tags WHERE name = ?", (name,)).fetchone()["id"]
        db.execute("INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)", (post_id, tid))


def like_escape(s):
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def get_post(post_id):
    post = get_db().execute(
        "SELECT p.*, u.username FROM posts p JOIN users u ON u.id = p.author_id WHERE p.id = ?",
        (post_id,),
    ).fetchone()
    if post is None:
        abort(404)
    return post


def get_post_tags(post_id):
    rows = get_db().execute(
        "SELECT t.name FROM tags t JOIN post_tags pt ON pt.tag_id = t.id "
        "WHERE pt.post_id = ? ORDER BY t.name",
        (post_id,),
    ).fetchall()
    return [r["name"] for r in rows]


def query_posts(where=None, params=None, sort="newest"):
    """Return (posts, page, pages, total) for the current ?page= value."""
    db = get_db()
    where = list(where or [])
    params = list(params or [])
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    total = db.execute("SELECT COUNT(*) AS c FROM posts p %s" % clause, params).fetchone()["c"]

    per_page = current_app.config["POSTS_PER_PAGE"]
    pages = max(1, math.ceil(total / per_page))
    page = min(max(request.args.get("page", 1, type=int), 1), pages)

    order = SORTS.get(sort, SORTS["newest"])
    rows = db.execute(
        "SELECT p.id, p.title, p.body, p.created_at, p.author_id, u.username, "
        "(SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comment_count, "
        "(SELECT group_concat(t.name, ',') FROM post_tags pt JOIN tags t ON t.id = pt.tag_id "
        " WHERE pt.post_id = p.id) AS tag_list "
        "FROM posts p JOIN users u ON u.id = p.author_id %s ORDER BY %s LIMIT ? OFFSET ?"
        % (clause, order),
        params + [per_page, (page - 1) * per_page],
    ).fetchall()
    posts = []
    for r in rows:
        d = dict(r)
        d["tags"] = sorted(d["tag_list"].split(",")) if d["tag_list"] else []
        posts.append(d)
    return posts, page, pages, total


def popular_tags(limit=12):
    return get_db().execute(
        "SELECT t.name, COUNT(*) AS n FROM tags t JOIN post_tags pt ON pt.tag_id = t.id "
        "GROUP BY t.id ORDER BY n DESC, t.name LIMIT ?",
        (limit,),
    ).fetchall()


# ------------------------------------------------- Week 4 + 6: list/search
@bp.route("/")
def index():
    q = request.args.get("q", "").strip()[:100]
    tag = request.args.get("tag", "").strip().lower()
    sort = request.args.get("sort", "newest")
    if sort not in SORTS:
        sort = "newest"

    where, params = [], []
    if q:
        like = "%" + like_escape(q) + "%"
        where.append("(p.title LIKE ? ESCAPE '\\' OR p.body LIKE ? ESCAPE '\\')")
        params += [like, like]
    if tag:
        where.append(
            "EXISTS (SELECT 1 FROM post_tags pt JOIN tags t ON t.id = pt.tag_id "
            "WHERE pt.post_id = p.id AND t.name = ?)"
        )
        params.append(tag)

    posts, page, pages, total = query_posts(where, params, sort)
    return render_template(
        "index.html", posts=posts, page=page, pages=pages, total=total,
        q=q, tag=tag, sort=sort, tags=popular_tags(),
    )


@bp.route("/user/<username>")
def profile(username):
    user = get_db().execute(
        "SELECT id, username, created_at FROM users WHERE username = ?", (username,)
    ).fetchone()
    if user is None:
        abort(404)
    posts, page, pages, total = query_posts(["p.author_id = ?"], [user["id"]])
    return render_template(
        "profile.html", profile_user=user, posts=posts, page=page, pages=pages, total=total
    )


# ----------------------------------------------------- Week 3: post CRUD
@bp.route("/post/<int:post_id>")
def detail(post_id):
    post = get_post(post_id)
    comments = get_db().execute(
        "SELECT c.*, u.username FROM comments c JOIN users u ON u.id = c.author_id "
        "WHERE c.post_id = ? ORDER BY c.created_at ASC, c.id ASC",
        (post_id,),
    ).fetchall()
    return render_template("post.html", post=post, comments=comments, tags=get_post_tags(post_id))


@bp.route("/create", methods=("GET", "POST"))
@login_required
def create():
    form = {}
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        body = request.form.get("body", "").strip()
        raw_tags = request.form.get("tags", "")
        form = {"title": title, "body": body, "tags": raw_tags}
        errors = validate_post(title, body)
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            db = get_db()
            post_id = db.execute(
                "INSERT INTO posts (author_id, title, body) VALUES (?, ?, ?)",
                (g.user["id"], title, body),
            ).lastrowid
            save_tags(db, post_id, parse_tags(raw_tags))
            db.commit()
            flash("Post published!", "success")
            return redirect(url_for("blog.detail", post_id=post_id))
    return render_template("post_form.html", form=form, editing=False)


def _owned_post_or_403(post_id):
    post = get_post(post_id)
    if post["author_id"] != g.user["id"]:
        abort(403)
    return post


@bp.route("/post/<int:post_id>/edit", methods=("GET", "POST"))
@login_required
def edit(post_id):
    post = _owned_post_or_403(post_id)
    form = {"title": post["title"], "body": post["body"], "tags": ", ".join(get_post_tags(post_id))}
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        body = request.form.get("body", "").strip()
        raw_tags = request.form.get("tags", "")
        form = {"title": title, "body": body, "tags": raw_tags}
        errors = validate_post(title, body)
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            db = get_db()
            db.execute(
                "UPDATE posts SET title = ?, body = ?, updated_at = datetime('now') WHERE id = ?",
                (title, body, post_id),
            )
            save_tags(db, post_id, parse_tags(raw_tags))
            db.commit()
            flash("Post updated.", "success")
            return redirect(url_for("blog.detail", post_id=post_id))
    return render_template("post_form.html", form=form, editing=True, post=post)


@bp.route("/post/<int:post_id>/delete", methods=("POST",))
@login_required
def delete(post_id):
    _owned_post_or_403(post_id)
    db = get_db()
    db.execute("DELETE FROM posts WHERE id = ?", (post_id,))
    db.commit()
    flash("Post deleted.", "success")
    return redirect(url_for("blog.index"))


# ------------------------------------------------------ Week 5: comments
@bp.route("/post/<int:post_id>/comment", methods=("POST",))
@login_required
def add_comment(post_id):
    get_post(post_id)
    body = request.form.get("body", "").strip()
    if not (1 <= len(body) <= 1000):
        flash("Comment must be between 1 and 1000 characters.", "error")
    else:
        db = get_db()
        db.execute(
            "INSERT INTO comments (post_id, author_id, body) VALUES (?, ?, ?)",
            (post_id, g.user["id"], body),
        )
        db.commit()
        flash("Comment added.", "success")
    return redirect(url_for("blog.detail", post_id=post_id) + "#comments")


@bp.route("/comment/<int:comment_id>/delete", methods=("POST",))
@login_required
def delete_comment(comment_id):
    db = get_db()
    row = db.execute(
        "SELECT c.id, c.post_id, c.author_id, p.author_id AS post_author "
        "FROM comments c JOIN posts p ON p.id = c.post_id WHERE c.id = ?",
        (comment_id,),
    ).fetchone()
    if row is None:
        abort(404)
    if g.user["id"] not in (row["author_id"], row["post_author"]):
        abort(403)
    db.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
    db.commit()
    flash("Comment deleted.", "success")
    return redirect(url_for("blog.detail", post_id=row["post_id"]) + "#comments")
